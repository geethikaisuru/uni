import { FC } from "react";

export const AboutPage: FC = () => {
  return <>About</>;
};
